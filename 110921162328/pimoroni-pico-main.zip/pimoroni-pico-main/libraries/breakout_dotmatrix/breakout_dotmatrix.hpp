#pragma once

#include "drivers/ltp305/ltp305.hpp"

namespace pimoroni {

  typedef LTP305 BreakoutDotMatrix;
}
