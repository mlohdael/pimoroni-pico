#pragma once

#include "drivers/trackball/trackball.hpp"

namespace pimoroni {

  typedef Trackball BreakoutTrackball;
}
