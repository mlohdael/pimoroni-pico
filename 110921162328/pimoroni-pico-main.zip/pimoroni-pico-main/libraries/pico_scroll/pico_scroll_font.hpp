#pragma once

// external font API
int render_text(const char *text, unsigned int nchr, unsigned char *buffer, unsigned int nbfr);
