#pragma once

#include "drivers/ltr559/ltr559.hpp"

namespace pimoroni {

  typedef LTR559 BreakoutLTR559;
}
