#pragma once

#include "drivers/ioexpander/ioexpander.hpp"

namespace pimoroni {

  typedef IOExpander BreakoutIOExpander;
}
