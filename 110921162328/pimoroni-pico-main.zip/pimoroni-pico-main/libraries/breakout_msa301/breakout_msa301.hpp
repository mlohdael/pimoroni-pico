#pragma once

#include "drivers/msa301/msa301.hpp"

namespace pimoroni {

  typedef MSA301 BreakoutMSA301;
}
