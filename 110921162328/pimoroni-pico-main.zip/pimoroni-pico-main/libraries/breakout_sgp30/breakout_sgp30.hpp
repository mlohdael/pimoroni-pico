#pragma once

#include "drivers/sgp30/sgp30.hpp"

namespace pimoroni {

  typedef SGP30 BreakoutSGP30;
}
